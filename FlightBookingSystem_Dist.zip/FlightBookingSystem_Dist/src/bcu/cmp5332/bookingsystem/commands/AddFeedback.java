package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Feedback;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.io.IOException;

/**
 * The AddFeedback class represents a command to add feedback to a booking in
 * the flight booking system. It implements the Command interface and requires
 * execution within a FlightBookingSystem instance.
 *
 * <p>
 * The feedback is identified by the booking ID, customer ID, and feedback
 * message. Upon execution, the feedback is added to the system and stored using
 * FlightBookingSystemData.
 @author Prashanta Acharya , Srijana Subedi
 */
public class AddFeedback implements Command {

    private final int bookingID;
    private final int customerID;
    private final String message;

    /**
     * Constructs an AddFeedback command with the specified booking ID, customer
     * ID, and feedback message.
     *
     * @param bookingID The ID of the booking
     * @param customerID The ID of the customer providing feedback
     * @param message The feedback message
     */
    public AddFeedback(int bookingID, int customerID, String message) {
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.message = message;
    }

    /**
     * Executes the AddFeedback command within the provided FlightBookingSystem
     * instance. Adds the feedback to the system using the specified booking ID,
     * customer ID, and feedback message. The updated system data is then stored
     * using FlightBookingSystemData.
     *
     * @param flightBookingSystem The FlightBookingSystem instance on which the
     * feedback is to be added
     * @throws FlightBookingSystemException If there is an issue adding the
     * feedback to the system
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        if (flightBookingSystem == null) {
            throw new FlightBookingSystemException("Flight booking system cannot be null");
        }

        // Debug print
        System.out.println("Attempting to add feedback for booking ID: " + bookingID);
        System.out.println("All customers in system: " + flightBookingSystem.getCustomers().size());
        for (Customer c : flightBookingSystem.getCustomers()) {
            System.out.println("Customer " + c.getId() + " has " + c.getBookings().size() + " bookings:");
            for (Booking b : c.getBookings()) {
                System.out.println("- Booking ID: " + b.getId());
            }
        }

        // Verify that the booking exists
        Booking booking = flightBookingSystem.getBookingByID(bookingID);
        if (booking == null) {
            throw new FlightBookingSystemException("Booking #" + bookingID + " does not exist");
        }

        // Verify that the customer exists and matches the booking
        Customer customer = flightBookingSystem.getCustomerByID(customerID);
        if (customer == null) {
            throw new FlightBookingSystemException("Customer #" + customerID + " does not exist");
        }

        if (booking.getCustomer().getId() != customerID) {
            throw new FlightBookingSystemException("Customer #" + customerID + " is not associated with booking #" + bookingID);
        }

        // Create a new Feedback object
        Feedback feedback = new Feedback(bookingID, customerID, message);

        // Add the feedback to the system
        flightBookingSystem.addFeedback(feedback);

        System.out.println("Feedback added for booking #" + bookingID + " by customer #" + customerID + ".");

        try {
            FlightBookingSystemData.store(flightBookingSystem);
        } catch (IOException e) {
            throw new FlightBookingSystemException("Error storing feedback: " + e.getMessage());
        }
    }
}
