package bcu.cmp5332.bookingsystem.model;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import java.time.LocalDate;

/**
 * @author Prashanta Acharya , Srijana Subedi
 * The Booking class represents a booking made by a customer for a flight.
 * It contains information such as booking ID, customer details, flight details,
 * booking date, price, and cancellation status.
 */
public class Booking {

    private final int id; // The unique identifier for the booking
    private Flight flight; // The flight booked by the customer
    private final Customer customer; // The customer who made the booking
    private final LocalDate bookingDate; // The date when the booking was made
    private boolean cancelled; // Flag indicating whether the booking is cancelled
    private double cancellationFee; // The fee charged upon cancellation of the booking
    private double rebookFee; // The fee charged upon rebooking the flight
    private String flightClass; // Add this field
    private String foodPreference; // Add this field
    
    /**
     * Constructs a Booking object with the specified parameters.
     *
     * @param id The unique identifier for the booking
     * @param flight The flight booked by the customer
     * @param customer The customer who made the booking
     * @param bookingDate The date when the booking was made
     * @param flightClass The class of the flight
     * @param foodPreference The food preference of the customer
     */
    public Booking(int id, Flight flight, Customer customer, LocalDate bookingDate, String flightClass, String foodPreference) {
        this.id = id;
        this.flight = flight;
        this.customer = customer;
        this.bookingDate = bookingDate;
        this.cancelled = false;
        this.flightClass = flightClass;
        this.foodPreference = foodPreference;
    }

    /**
     * Returns the unique identifier of the booking.
     *
     * @return The booking ID
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the customer who made the booking.
     *
     * @return The customer object
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Returns the flight booked by the customer.
     *
     * @return The flight object
     */
    public Flight getFlight() {
        return flight;
    }

    /**
     * Sets the flight booked by the customer.
     *
     * @param flight The flight object
     */
    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    /**
     * Returns the date when the booking was made.
     *
     * @return The booking date
     */
    public LocalDate getBookingDate() {
        return bookingDate;
    }

    /**
     * Returns the class of the flight.
     *
     * @return The flight class
     */
    public String getFlightClass() {
        return flightClass;
    }

    /**
     * Sets the class of the flight.
     *
     * @param flightClass The flight class
     */
    public void setFlightClass(String flightClass) {
        this.flightClass = flightClass;
    }

    /**
     * Returns the food preference of the customer.
     *
     * @return The food preference
     */
    public String getFoodPreference() {
        return foodPreference;
    }

    /**
     * Sets the food preference of the customer.
     *
     * @param foodPreference The food preference
     */
    public void setFoodPreference(String foodPreference) {
        this.foodPreference = foodPreference;
    }

    /**
     * Returns the price of the booking.
     *
     * @return The booking price
     */
    public double getPrice() {
        try {
            double basePrice = flight.calculatePrice(bookingDate);
            return "BUSINESS".equalsIgnoreCase(flightClass) ? basePrice * 1.10 : basePrice;
        } catch (FlightBookingSystemException ex) {
            return 0.0;
        }
    }

    /**
     * Checks whether the booking is cancelled.
     *
     * @return True if the booking is cancelled, otherwise false
     */
    public boolean isCancelled() {
        return cancelled;
    }

    /**
     * Cancels the booking if it is not already cancelled.
     * Removes the customer from the flight and sets cancellation fee.
     */
    public void cancelBooking() {
        if (!cancelled) { // Check if the booking is not already cancelled
            this.cancelled = true;
            flight.removePassenger(customer);

            // Set cancellation fee only if the booking is cancelled
            this.cancellationFee = getPrice() * 0.1;
        }
    }

    /**
     * Generates and returns a string containing the details of the booking.
     *
     * @return Details of the booking
     */
    public String getDetails() {
        StringBuilder details = new StringBuilder();
        details.append("Booking ID: ").append(id).append("\n");
        details.append("Customer: ").append(customer.getName()).append("\n");
        details.append("Flight: ").append(flight.getFlightNumber()).append("\n");
        details.append("Booking Date: ").append(bookingDate.toString()).append("\n");
        details.append("Price: ").append(getPrice()).append("\n");
        details.append("Flight Class: ").append(flightClass).append("\n");
        details.append("Food Preference: ").append(foodPreference).append("\n");
        details.append("Status: ").append(cancelled ? "Cancelled" : "Active").append("\n");
        return details.toString();
    }

    /**
     * Returns the cancellation fee of the booking.
     *
     * @return The cancellation fee
     */
    public double getCancellationFee() {
        return cancellationFee;
    }

    /**
     * Sets the cancellation fee of the booking.
     *
     * @param cancellationFee The cancellation fee
     */
    public void setCancellationFee(double cancellationFee) {
        this.cancellationFee = cancellationFee;
    }

    /**
     * Returns the rebooking fee of the booking.
     *
     * @return The rebooking fee
     */
    public double getRebookFee() {
        return rebookFee;
    }

    /**
     * Sets the rebooking fee of the booking.
     *
     * @param rebookFee The rebooking fee
     */
    public void setRebookFee(double rebookFee) {
        this.rebookFee = rebookFee;
    }
}
