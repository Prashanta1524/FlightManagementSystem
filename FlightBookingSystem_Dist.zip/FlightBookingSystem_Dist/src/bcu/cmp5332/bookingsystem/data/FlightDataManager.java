package bcu.cmp5332.bookingsystem.data;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Scanner;

/**
 * Represents a data manager for handling flight data.
 */
public class FlightDataManager implements DataManager {

    private final String RESOURCE = "./resources/data/flights.txt";
    private final String SEPARATOR = "";

    /**
     * Loads flight data from a file into the flight booking system.
     *
     * @param fbs The flight booking system.
     * @throws IOException If an I/O error occurs.
     * @throws FlightBookingSystemException If there is an error in the flight
     * data.
     */
    @Override
    public void loadData(FlightBookingSystem fbs) throws IOException, FlightBookingSystemException {
        try (Scanner sc = new Scanner(new File(RESOURCE))) {
            int line_idx = 1;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] properties = line.split(SEPARATOR, -1);
                if (properties.length < 7) {
                    throw new FlightBookingSystemException("Invalid data format in flights.txt on line " + line_idx);
                }
                try {
                    String idStr = properties[0].trim();
                    if (idStr.isEmpty()) {
                        throw new NumberFormatException("Empty flight ID");
                    }
                    int id = Integer.parseInt(idStr);
                    String flightNumber = properties[1].trim();
                    String origin = properties[2].trim();
                    String destination = properties[3].trim();
                    LocalDate departureDate = LocalDate.parse(properties[4].trim());
                    int numberOfSeats = Integer.parseInt(properties[5].trim());
                    double price = Double.parseDouble(properties[6].trim());
                    Flight flight = new Flight(id, flightNumber, origin, destination, departureDate, numberOfSeats, price);
                    fbs.addFlight(flight);
                } catch (NumberFormatException ex) {
                    throw new FlightBookingSystemException("Unable to parse flight id or number of seats on line " + line_idx
                            + "\nError: " + ex);
                }
                line_idx++;
            }
        }
    }

    /**
     * Stores flight data from the flight booking system into a file.
     *
     * @param fbs The flight booking system.
     * @throws IOException If an I/O error occurs.
     */
    @Override
    public void storeData(FlightBookingSystem fbs) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))) {
            for (Flight flight : fbs.getFlights()) {
                out.print(flight.getId() + SEPARATOR);
                out.print(flight.getFlightNumber() + SEPARATOR);
                out.print(flight.getOrigin() + SEPARATOR);
                out.print(flight.getDestination() + SEPARATOR);
                out.print(flight.getDepartureDate() + SEPARATOR);
                out.print(flight.getNumberOfSeats() + SEPARATOR);
                out.print(flight.getPrice() + SEPARATOR);
                out.println();
            }
        }
    }
}
